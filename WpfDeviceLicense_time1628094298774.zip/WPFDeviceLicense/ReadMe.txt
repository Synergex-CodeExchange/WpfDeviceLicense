
Title:			WPFDeviceLicense

Platform:		Synergy .NET (developed in Visual Studio 2014)

Synergy version:	10.3.1 or higher

Author:			James Sahaj, Synergex Development

Revision:		2.0

========================================================================
Description
========================================================================

This is a sample of a WPF application, WPFDeviceLicense, using Synergy Device Licensing.  The purpose is to
show how the calls are made and how error handling is done.  Before compiling and running this code, you will 
need to register with Synergex to get your company's PublicKey and AppGUID and add these values to the
SynergyDeviceLicense attribute in LicenseClass.dbl



